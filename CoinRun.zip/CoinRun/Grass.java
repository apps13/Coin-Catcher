import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Grass here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Grass extends Actor
{
    /**
     * Act - do whatever the Grass wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Grass()
    {
        this(100,25);
    }
    
    public Grass(int width, int height){
        GreenfootImage image=getImage();
        image.scale(width,height);
        setImage(image);
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
}
